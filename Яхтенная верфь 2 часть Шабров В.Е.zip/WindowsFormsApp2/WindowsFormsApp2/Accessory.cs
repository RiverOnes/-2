namespace WindowsFormsApp2
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Accessory")]
    public partial class Accessory
    {
        [Key]
        [StringLength(10)]
        public string Accessory_ID { get; set; }

        [Required]
        public string AccName { get; set; }

        [Required]
        public string DescriptionOfAccessory { get; set; }

        public int Price { get; set; }

        public double VAT { get; set; }

        public int Inventory { get; set; }

        public int OrderLevel { get; set; }

        public int OrderBatch { get; set; }

        [Required]
        [StringLength(10)]
        public string Partner_ID { get; set; }
    }
}
