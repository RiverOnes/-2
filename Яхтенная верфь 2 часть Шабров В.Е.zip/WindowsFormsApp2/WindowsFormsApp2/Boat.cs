namespace WindowsFormsApp2
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Boat")]
    public partial class Boat
    {
        [Key]
        [StringLength(10)]
        public string boat_ID { get; set; }

        [Required]
        [StringLength(50)]
        public string Model { get; set; }

        [Required]
        [StringLength(50)]
        public string BoatType { get; set; }

        public int NumberOfRowers { get; set; }

        [Required]
        [StringLength(50)]
        public string Mast { get; set; }

        [Required]
        [StringLength(50)]
        public string Colour { get; set; }

        [Required]
        [StringLength(50)]
        public string Wood { get; set; }

        [Column(TypeName = "money")]
        public decimal BasePrice { get; set; }

        public int VAT { get; set; }
    }
}
